# Bislak

Bislak is a simple and basic manual spammer for Discord. It spams messages in Italian and was made for a little group of Discord Italian raiders. What you need to do is selecting the Discord textbox and it will automatically spam random messages. It's funny! Enjoy it.
